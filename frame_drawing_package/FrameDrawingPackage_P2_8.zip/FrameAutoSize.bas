Attribute VB_Name = "FrameAutoSize"
Option Explicit

' FrameAutoSize package P2.3; native SolidWorks test required.
' Standard references: SolidWorks type library and constant type library.
Private Const VERSION As String = "FrameAutoSize Package P2.8"
Private Const FRAME_NAME As String = "����"
Private Const TOP_OVERALL_WIDTH As Boolean = True
Private Const MODEL_TOL As Double = 0.00005
Private Const VALUE_TOL As Double = 0.000001
Private Const GAP As Double = 0.007
Private Const STEP_GAP As Double = 0.006
Private Const AXIS_COS As Double = 0.9999
Private Const MAX_BODIES As Long = 1000
Private Const MAX_EDGES As Long = 100000
Private Type MemberInfo
    Body As SldWorks.Body2
    Label As String
    Metadata As String
    Profile As Boolean
    AxisOK As Boolean
    CutLength As Double
    AxisReason As String
    Direction As String
    MinX As Double
    MaxX As Double
    MinY As Double
    MaxY As Double
    AxisX As Double
    AxisY As Double
    AxisZ As Double
    MinZ As Double
    MaxZ As Double
    CarriesTubePost As Boolean
    PostXLocatedByChannel As Boolean
    PostYLocatedByChannel As Boolean
    SlotChecked As Boolean
    HasSlot As Boolean
End Type
Private Type EdgeInfo
    Source As SldWorks.Edge
    Member As Long
    X1 As Double
    Y1 As Double
    X2 As Double
    Y2 As Double
End Type
Private Type DimensionJob
    Datum As Long
    Target As Long
    Horizontal As Boolean
    Expected As Double
    AtX As Double
    AtY As Double
    Label As String
    Station As Long
End Type
Private sw As SldWorks.SldWorks
Private doc As SldWorks.ModelDoc2
Private vw As SldWorks.View
Private partModel As SldWorks.ModelDoc2
Private instance As SldWorks.Component2
Private utility As SldWorks.MathUtility
Private componentTransform As SldWorks.MathTransform
Private viewTransform As SldWorks.MathTransform
Private members() As MemberInfo, memberCount As Long
Private edges() As EdgeInfo, edgeCount As Long
Private jobs() As DimensionJob, jobCount As Long
Private visited As Collection, created As Collection, expected As Collection
Private phase As String
Private viewScale As Double
Private origin As Variant, basisX As Variant, basisY As Variant, basisZ As Variant
Private leftX As Double, rightX As Double, bottomY As Double, topY As Double
Private preferenceKnown As Boolean, oldPreference As Boolean
Private modeKnown As Boolean, oldProjected As Boolean

Private packageApp As SldWorks.SldWorks
Private packageDrawing As SldWorks.ModelDoc2
Private packageView As SldWorks.View
Private packageFrame As SldWorks.Component2
Private packageCreated As Long
Private packageMeasuring As Boolean
Private packageEnvelope As Variant

Public Function RunForPackage(ByVal host As SldWorks.SldWorks, ByVal targetDrawing As SldWorks.ModelDoc2, _
                              ByVal targetView As SldWorks.View, ByVal targetFrame As SldWorks.Component2, _
                              ByVal viewMode As String) As Long
    On Error GoTo Failed
    Set packageApp = host: Set packageDrawing = targetDrawing
    Set packageView = targetView: Set packageFrame = targetFrame
    packageCreated = 0: packageMeasuring = False
    RunMacro viewMode, False
    RunForPackage = packageCreated
    ClearPackageContext
    Exit Function
Failed:
    Dim number As Long, origin As String, message As String
    number = Err.Number: origin = Err.Source: message = Err.Description
    ClearPackageContext
    Err.Raise number, origin, message
End Function

Public Function MeasureForPackage(ByVal host As SldWorks.SldWorks, ByVal targetDrawing As SldWorks.ModelDoc2, _
                                  ByVal targetView As SldWorks.View, ByVal targetFrame As SldWorks.Component2, _
                                  ByVal viewMode As String) As Variant
    On Error GoTo Failed
    Set packageApp = host: Set packageDrawing = targetDrawing
    Set packageView = targetView: Set packageFrame = targetFrame
    packageMeasuring = True: packageEnvelope = Empty
    RunMacro viewMode, False
    MeasureForPackage = packageEnvelope
    ClearPackageContext
    Exit Function
Failed:
    Dim number As Long, origin As String, message As String
    number = Err.Number: origin = Err.Source: message = Err.Description
    ClearPackageContext
    Err.Raise number, origin, message
End Function

Private Function PlanEnvelope() As Variant
    Dim box As Variant, i As Long
    box = vw.GetOutline
    If HasItems(box) = False Then Fail "��� �������� ��� ����������."
    For i = 1 To jobCount
        If jobs(i).AtX - 0.016 < box(0) Then box(0) = jobs(i).AtX - 0.016
        If jobs(i).AtX + 0.016 > box(2) Then box(2) = jobs(i).AtX + 0.016
        If jobs(i).AtY - 0.009 < box(1) Then box(1) = jobs(i).AtY - 0.009
        If jobs(i).AtY + 0.009 > box(3) Then box(3) = jobs(i).AtY + 0.009
    Next i
    PlanEnvelope = box
End Function

Private Sub ClearPackageContext()
    Set packageApp = Nothing: Set packageDrawing = Nothing
    Set packageView = Nothing: Set packageFrame = Nothing
    packageMeasuring = False: packageEnvelope = Empty
End Sub

Private Sub main()
    RunMacro "AUTO", False
End Sub

Private Sub Front()
    RunMacro "FRONT", False
End Sub

Private Sub Top()
    RunMacro "TOP", False
End Sub

Private Sub DiagnoseContext()
    RunMacro "CONTEXT", True
End Sub

Private Sub Diagnose()
    RunMacro "AUTO", True
End Sub

Private Sub DiagnoseFront()
    RunMacro "FRONT", True
End Sub

Private Sub DiagnoseTop()
    RunMacro "TOP", True
End Sub

Private Sub RunMacro(ByVal requested As String, ByVal diagnostic As Boolean)
    On Error GoTo Failed
    ResetState
    phase = "context"
    Set sw = packageApp
    Set doc = packageDrawing
    WriteLog "START " & VERSION & "; " & CStr(Now) & "; requested=" & requested
    LogContext doc
    If requested = "CONTEXT" Then
        Dim contextReport As String
        contextReport = VERSION & vbCrLf & "����������� ���������� SolidWorks ���������." & vbCrLf & _
            "��������� �� ����������." & vbCrLf & "�����������: ���� Immediate ��������� VBA (Ctrl+G)."
        ReleaseObjects
        MsgBox contextReport, vbInformation, VERSION
        Exit Sub
    End If
    If doc Is Nothing Then Fail "���� ��������� SolidWorks �� ������� �������� ��������. ��������� DiagnoseContext � �������� ������."
    If doc.GetType <> swDocDRAWING Then Fail "�������� �������� �� �������� ��������: " & doc.GetTitle
    Dim mode As String
    Set vw = packageView
    If vw Is Nothing Then Fail "�� ������� �������� ���."
    Set utility = sw.GetMathUtility
    Set viewTransform = vw.ModelToViewTransform
    If utility Is Nothing Then Fail "��� MathUtility."
    If viewTransform Is Nothing Then Fail "��� �������������� ����."
    If vw.IsBroken Then Fail "����������� ���� � R1 �� ��������������."
    If vw.IsCropped Then Fail "���������� ���� � R1 �� ��������������."
    If vw.IsModelBreakState Then Fail "��� � �������� ������ � R1 �� ��������������."
    If vw.GetBreakOutSectionCount > 0 Then Fail "��� � ������� �������� � R1 �� ��������������."
    Dim section As Object, detail As Object
    Set section = vw.GetSection: Set detail = vw.GetDetail
    If Not section Is Nothing Then Fail "�������� ������� ���, �� ������."
    If Not detail Is Nothing Then Fail "�������� ������� ���, �� �������� �������."
    viewScale = vw.ScaleDecimal
    If viewScale <= 0# Then Fail "������������ ������� ����."
    WriteLog "VIEW=" & vw.GetName2 & "; orientation=" & vw.GetOrientationName & "; scale=" & CStr(viewScale)
    mode = ResolveMode(requested, diagnostic)
    WriteLog "MODE=" & mode & "; diagnostic=" & CStr(diagnostic)
    ResolveFrame
    phase = "projection"
    origin = Project(Array(0#, 0#, 0#))
    basisX = Project(Array(1#, 0#, 0#))
    basisY = Project(Array(0#, 1#, 0#))
    basisZ = Project(Array(0#, 0#, 1#))
    WriteLog "BASIS origin=" & PointText(origin) & "; X=" & PointText(basisX) & "; Y=" & PointText(basisY) & "; Z=" & PointText(basisZ)
    ValidateBasis
    Dim filtered As Variant
    filtered = vw.Bodies
    If HasItems(filtered) Then Fail "��� ��������� ���������� ������. �������� ������ ��� ������/����."
    phase = "bodies"
    ReadBodies
    phase = "cut-list"
    WalkFeatures partModel.FirstFeature
    phase = "geometry"
    ReadGeometry
    If diagnostic = False Then RequireAxes
    phase = "plan"
    If mode = "UNKNOWN" Then
        WriteLog "No automatic mode for this orientation; use Front or Top for dimension creation."
    Else
        BuildPlan mode
    End If
    If packageMeasuring Then
        If jobCount = 0 Then Fail "��� �������� ��� ����������. ��������� ���� � ���������� �����."
        packageEnvelope = PlanEnvelope()
    ElseIf diagnostic Then
        ProbePlan
        WriteLog "DIAGNOSTIC COMPLETE; no dimensions created."
    Else
        If jobCount = 0 Then Fail "��� �������� ��� ��������. ��������� Diagnose � �������� ������."
        phase = "create"
        CreateDimensions
        phase = "rebuild"
        doc.EditRebuild3
        If created.Count <> jobCount Or expected.Count <> jobCount Then Fail "������� �� ��� ��������������� �������."
        ValidateAll
        If RestorePreference() = False Then Fail "�� ������������� ��������� ����� �������."
        doc.GraphicsRedraw2
        packageCreated = created.Count
        WriteLog "SUCCESS dimensions=" & CStr(created.Count)
    End If
    Dim report As String
    If diagnostic Then
        report = VERSION & vbCrLf & "����: " & partModel.GetTitle & vbCrLf & _
            "���: " & memberCount & "; ������������� ��������: " & jobCount & vbCrLf & _
            "����������� ���������. ����� �� �������." & vbCrLf & "�����������: ���� Immediate ��������� VBA (Ctrl+G)."
    Else
        report = "��������� �������"
    End If
    ReleaseObjects
    Exit Sub
Failed:
    Dim message As String, number As Long, rollbackOK As Boolean, restoreOK As Boolean
    number = Err.Number: message = Err.Description
    WriteLog "FAIL phase=" & phase & "; error=" & CStr(number) & "; " & message
    rollbackOK = Rollback()
    restoreOK = RestorePreference()
    If RestoreMode() = False Then restoreOK = False
    WriteLog "ROLLBACK=" & CStr(rollbackOK) & "; settings restored=" & CStr(restoreOK)
    report = VERSION & vbCrLf & "����: " & phase & vbCrLf & message & vbCrLf & "�����������: ���� Immediate ��������� VBA (Ctrl+G)."
    If rollbackOK = False Then report = report & vbCrLf & "����� ����� �������� �� �������; ��������� �����."
    If restoreOK = False Then report = report & vbCrLf & "��������� ��������� �������� ���� � ����� ��������."
    ReleaseObjects
    Err.Raise vbObjectError + 3301, VERSION, report
End Sub

Private Sub LogContext(ByVal captured As SldWorks.ModelDoc2)
    On Error GoTo Failed
    Dim current As SldWorks.ModelDoc2, documents As Variant, candidate As SldWorks.ModelDoc2, i As Long
    WriteLog "CONTEXT pid=" & CStr(sw.GetProcessID) & "; documentCount=" & CStr(sw.GetDocumentCount)
    LogContextDocument "active-at-start", captured
    Set current = sw.ActiveDoc
    LogContextDocument "active-now", current
    documents = sw.GetDocuments
    If HasItems(documents) = False Then
        WriteLog "CONTEXT documents=[]"
        Exit Sub
    End If
    For i = LBound(documents) To UBound(documents)
        Set candidate = documents(i)
        LogContextDocument "open[" & CStr(i) & "]", candidate
    Next i
    Exit Sub
Failed:
    WriteLog "CONTEXT diagnostic error=" & CStr(Err.Number) & "; " & Err.Description
End Sub

Private Sub LogContextDocument(ByVal label As String, ByVal model As SldWorks.ModelDoc2)
    On Error GoTo Failed
    If model Is Nothing Then
        WriteLog "CONTEXT " & label & "=Nothing"
        Exit Sub
    End If
    Dim selection As SldWorks.SelectionMgr, count As Long, selected As Object, selectedView As SldWorks.View
    WriteLog "CONTEXT " & label & "; title=" & model.GetTitle & "; type=" & CStr(model.GetType) & "; path=" & model.GetPathName
    Set selection = model.SelectionManager
    If selection Is Nothing Then Exit Sub
    count = selection.GetSelectedObjectCount2(-1)
    WriteLog "CONTEXT " & label & "; selectionCount=" & CStr(count)
    If count > 0 Then
        Set selected = selection.GetSelectedObject6(1, -1)
        WriteLog "CONTEXT " & label & "; firstSelectedType=" & TypeName(selected)
        If model.GetType = swDocDRAWING Then
            Set selectedView = selection.GetSelectedObjectsDrawingView2(1, -1)
            If Not selectedView Is Nothing Then WriteLog "CONTEXT " & label & "; selectedView=" & selectedView.GetName2
        End If
    End If
    Exit Sub
Failed:
    WriteLog "CONTEXT " & label & "; diagnostic error=" & CStr(Err.Number) & "; " & Err.Description
End Sub

Private Sub ResetState()
    ReleaseObjects
    Erase members: Erase edges: Erase jobs
    memberCount = 0: edgeCount = 0: jobCount = 0
    Set visited = New Collection
    Set created = New Collection
    Set expected = New Collection
    preferenceKnown = False: modeKnown = False
    phase = "init"
End Sub

Private Sub ReleaseObjects()
    Set instance = Nothing: Set partModel = Nothing: Set vw = Nothing
    Set componentTransform = Nothing: Set viewTransform = Nothing
    Set utility = Nothing: Set doc = Nothing: Set sw = Nothing
    Set visited = Nothing: Set created = Nothing: Set expected = Nothing
    Erase members: Erase edges: Erase jobs
End Sub

Private Function ResolveMode(ByVal requested As String, ByVal diagnostic As Boolean) As String
    If requested <> "AUTO" Then ResolveMode = requested: Exit Function
    Dim name As String, answer As VbMsgBoxResult
    name = LCase$(vw.GetOrientationName)
    If InStr(name, "front") > 0 Or InStr(name, "�������") > 0 Then
        ResolveMode = "FRONT": Exit Function
    End If
    If InStr(name, "top") > 0 Or InStr(name, "������") > 0 Then
        ResolveMode = "TOP": Exit Function
    End If
    If diagnostic Then ResolveMode = "UNKNOWN": Exit Function
    answer = MsgBox("SolidWorks �� �������� ����������� ��� ����������." & vbCrLf & _
        "�� � ��� �������. ��� � ��� ������. ������ � �����.", vbYesNoCancel + vbQuestion, VERSION)
    If answer = vbCancel Then Fail "������ �������."
    If answer = vbYes Then ResolveMode = "FRONT" Else ResolveMode = "TOP"
End Function

Private Sub ResolveFrame()
    Dim reference As SldWorks.ModelDoc2
    Set reference = vw.ReferencedDocument
    If reference Is Nothing Then Fail "�� ��������� ������ ���� ������."
    CheckConfiguration reference, vw.ReferencedConfiguration
    Set instance = packageFrame
    If instance Is Nothing Then Fail "�� ������� ��������� ���� ��� ��������."
    Set partModel = instance.GetModelDoc2
    If partModel Is Nothing Then Fail "�� ��������� ������ ����."
    If partModel.GetType <> swDocPART Then Fail "���� ������ ���� ������������ �������."
    CheckConfiguration partModel, instance.ReferencedConfiguration
    Dim drawingComponent As SldWorks.Component2
    Set drawingComponent = FramePackageSupport.DrawingComponentFor(vw, instance)
    Set componentTransform = instance.Transform2
    If componentTransform Is Nothing Then Fail "��� �������������� ���������� ����."
End Sub

Private Function IsFrameName(ByVal path As String, ByVal name As String) As Boolean
    Dim stem As String, position As Long
    stem = Replace(path, "/", "\")
    position = InStrRev(stem, "\")
    If position > 0 Then stem = Mid$(stem, position + 1)
    If Len(stem) = 0 Then stem = name
    position = InStrRev(stem, ".")
    If position > 0 Then
        If LCase$(Mid$(stem, position)) <> ".sldprt" Then Exit Function
        stem = Left$(stem, position - 1)
    End If
    IsFrameName = (InStr(1, stem, FRAME_NAME, vbTextCompare) > 0 Or InStr(1, stem, "frame", vbTextCompare) > 0)
End Function

Private Function ResolveInstance(ByVal model As SldWorks.ModelDoc2, ByVal wanted As SldWorks.Component2) As SldWorks.Component2
    Dim assembly As SldWorks.AssemblyDoc, values As Variant, candidate As SldWorks.Component2
    Dim root As SldWorks.DrawingComponent, rootComp As SldWorks.Component2
    Dim rootName As String, aliasName As String, i As Long, count As Long, sameName As Boolean
    Set root = vw.RootDrawingComponent
    If Not root Is Nothing Then
        rootName = root.Name
        Set rootComp = root.Component
        If Not rootComp Is Nothing Then aliasName = rootComp.Name2
    End If
    Set assembly = model
    values = assembly.GetComponents(False)
    If HasItems(values) = False Then Fail "�� ������� ��������� ������ ������."
    For i = LBound(values) To UBound(values)
        Set candidate = values(i)
        sameName = (StrComp(wanted.Name2, candidate.Name2, vbTextCompare) = 0)
        If Len(rootName) > 0 Then sameName = sameName Or (StrComp(wanted.Name2, rootName & "/" & candidate.Name2, vbTextCompare) = 0)
        If Len(aliasName) > 0 Then sameName = sameName Or (StrComp(wanted.Name2, aliasName & "/" & candidate.Name2, vbTextCompare) = 0)
        If sameName Then
            If StrComp(wanted.GetPathName, candidate.GetPathName, vbTextCompare) = 0 Then
                If StrComp(wanted.ReferencedConfiguration, candidate.ReferencedConfiguration, vbTextCompare) = 0 Then
                    count = count + 1
                    Set ResolveInstance = candidate
                End If
            End If
        End If
    Next i
    If count <> 1 Then Fail "������������� ��������� ���� � ������: " & count
End Function

Private Sub CheckConfiguration(ByVal model As SldWorks.ModelDoc2, ByVal requested As String)
    Dim configuration As SldWorks.Configuration
    Set configuration = model.ConfigurationManager.ActiveConfiguration
    If configuration Is Nothing Then Fail "�� ��������� ������������ " & model.GetTitle
    WriteLog "CONFIG " & model.GetTitle & "; active=" & configuration.Name & "; requested=" & requested
    If Len(requested) > 0 Then
        If StrComp(configuration.Name, requested, vbTextCompare) <> 0 Then _
            Fail "������������ �������� ������ �� ��������� � �����: " & model.GetTitle & ". ����������� " & requested
    End If
End Sub

Private Sub ReadBodies()
    Dim part As SldWorks.PartDoc, values As Variant, i As Long
    Set part = partModel
    values = part.GetBodies2(swSolidBody, True)
    If HasItems(values) = False Then Fail "� ������ ���� ��� ��������� ������ ���."
    memberCount = UBound(values) - LBound(values) + 1
    If memberCount > MAX_BODIES Then Fail "������� ����� ��� ��� ���� ������."
    ReDim members(1 To memberCount)
    For i = LBound(values) To UBound(values)
        Set members(i - LBound(values) + 1).Body = values(i)
        members(i - LBound(values) + 1).Label = values(i).Name
    Next i
End Sub

Private Sub WalkFeatures(ByVal first As SldWorks.Feature, Optional ByVal subLevel As Boolean = False)
    Dim feature As SldWorks.Feature, old As SldWorks.Feature, seen As Boolean
    Set feature = first
    Do While Not feature Is Nothing
        seen = False
        For Each old In visited
            If sw.IsSame(old, feature) = swObjectSame Then seen = True: Exit For
        Next old
        If seen = False Then
            visited.Add feature
            If feature.GetTypeName2 = "CutListFolder" Then ReadFolder feature
            WalkFeatures feature.GetFirstSubFeature, True
        End If
        If subLevel Then
            Set feature = feature.GetNextSubFeature
        Else
            Set feature = feature.GetNextFeature
        End If
    Loop
End Sub

Private Sub ReadFolder(ByVal feature As SldWorks.Feature)
    Dim folder As SldWorks.BodyFolder, manager As SldWorks.CustomPropertyManager
    Dim values As Variant, names As Variant, raw As String, resolved As String, text As String
    Dim wasResolved As Boolean, linked As Boolean, status As Long, i As Long, j As Long, k As Long
    Dim body As SldWorks.Body2, cutLength As Double, token As String, candidateLength As Double
    Set folder = feature.GetSpecificFeature2
    If folder Is Nothing Then Exit Sub
    values = folder.GetBodies
    If HasItems(values) = False Then Exit Sub
    Set manager = feature.CustomPropertyManager
    names = manager.GetNames
    text = feature.Name
    If HasItems(names) Then
        For i = LBound(names) To UBound(names)
            raw = "": resolved = ""
            status = manager.Get6(CStr(names(i)), True, raw, resolved, wasResolved, linked)
            WriteLog "PROPERTY folder=" & feature.Name & "; name=" & CStr(names(i)) & "; raw=" & raw & "; resolved=" & resolved & _
                "; status=" & CStr(status) & "; wasResolved=" & CStr(wasResolved) & "; linked=" & CStr(linked)
            text = text & " | " & CStr(names(i)) & "=" & resolved
            token = PropertyToken(raw)
            If token = "LENGTH" Or token = "SW-LENGTH" Then
                If wasResolved <> False And linked <> False Then
                    candidateLength = PlainNumber(resolved) * LengthFactor()
                    If candidateLength > 0# Then
                        If cutLength > 0# And Abs(cutLength - candidateLength) > VALUE_TOL Then Fail "�������������� �������� LENGTH: " & feature.Name
                        cutLength = candidateLength
                    End If
                End If
            End If
        Next i
    End If
    For j = LBound(values) To UBound(values)
        Set body = values(j)
        For k = 1 To memberCount
            If sw.IsSame(body, members(k).Body) = swObjectSame Then
                members(k).Metadata = members(k).Metadata & " | " & text
                If members(k).CutLength > 0# And cutLength > 0# Then
                    If Abs(members(k).CutLength - cutLength) > VALUE_TOL Then Fail "���� � ������ ������� LENGTH: " & members(k).Label
                End If
                If cutLength > 0# Then members(k).CutLength = cutLength
                Exit For
            End If
        Next k
    Next j
End Sub

Private Function ProfileEvidence(ByVal index As Long) As Boolean
    Dim text As String, keywords As Variant, word As Variant
    text = LCase$(members(index).Metadata & " " & members(index).Label)
    ' Sheet/cut plates must not be treated as profiles even if long.
    keywords = Array("�������", "���� ", "sheet", "plate")
    For Each word In keywords
        If InStr(text, CStr(word)) > 0 Then Exit Function
    Next word
    keywords = Array("����", "�������", "������", "������", "�����", "tube", "pipe", "channel", "angle", "rhs", "shs", "upn", "u channel")
    For Each word In keywords
        If InStr(text, CStr(word)) > 0 Then ProfileEvidence = True: Exit Function
    Next word
    Dim values As Variant, feature As SldWorks.Feature, i As Long, kind As String
    values = members(index).Body.GetFeatures
    If HasItems(values) Then
        For i = LBound(values) To UBound(values)
            Set feature = values(i)
            kind = feature.GetTypeName2
            WriteLog "BODYFEATURE " & members(index).Label & "; " & kind & "; " & feature.Name
            If kind = "WeldMemberFeat" Then ProfileEvidence = True
        Next i
    End If
End Function

Private Sub ReadGeometry()
    Dim i As Long, j As Long, values As Variant, edge As SldWorks.Edge
    Dim a As Variant, b As Variant, p As Variant, q As Variant, length As Double
    Dim ax As Double, ay As Double, az As Double, dx As Double, dy As Double, dz As Double
    Dim projected As Variant, validProfiles As Long, matches As Long, ambiguous As Boolean
    For i = 1 To memberCount
        members(i).Profile = ProfileEvidence(i)
        members(i).MinX = Support(i, 0, -1#): members(i).MaxX = Support(i, 0, 1#)
        members(i).MinY = Support(i, 1, -1#): members(i).MaxY = Support(i, 1, 1#)
        matches = 0: ambiguous = False
        values = members(i).Body.GetEdges
        If HasItems(values) Then
            For j = LBound(values) To UBound(values)
                Set edge = values(j)
                If Straight(edge, a, b, length) Then
                    p = Project(a): q = Project(b)
                    AddEdge edge, i, p, q
                    If members(i).CutLength > 0# Then
                        If Abs(length - members(i).CutLength) <= VALUE_TOL Then
                            dx = (b(0) - a(0)) / length
                            dy = (b(1) - a(1)) / length
                            dz = (b(2) - a(2)) / length
                            If matches = 0 Then
                                ax = dx: ay = dy: az = dz
                            Else
                                If Abs(ax * dx + ay * dy + az * dz) < 0.999999 Then ambiguous = True
                            End If
                            matches = matches + 1
                        End If
                    End If
                End If
            Next j
        End If
        members(i).Direction = "UNKNOWN"
        members(i).AxisReason = "No resolved linked LENGTH or no matching straight edges"
        If matches > 0 And ambiguous = False Then
            projected = Project(Array(ax, ay, az))
            members(i).AxisX = (projected(0) - origin(0)) / viewScale
            members(i).AxisY = (projected(1) - origin(1)) / viewScale
            members(i).AxisZ = (projected(2) - origin(2)) / viewScale
            members(i).Direction = AxisDirection(members(i).AxisX, members(i).AxisY, members(i).AxisZ)
            members(i).AxisOK = (members(i).Direction <> "OBLIQUE")
            members(i).AxisReason = "Validated parallel full-LENGTH edges: " & CStr(matches)
            If members(i).AxisOK = False Then members(i).AxisReason = "Oblique profile in this view"
        End If
        If ambiguous Then members(i).AxisReason = "Full-LENGTH edges have different directions; ambiguous axis"
        WriteLog "BODY " & CStr(i) & "; name=" & members(i).Label & "; profile=" & CStr(members(i).Profile) & _
            "; LENGTH mm=" & CStr(members(i).CutLength * 1000#) & "; axisOK=" & CStr(members(i).AxisOK) & "; direction=" & members(i).Direction & _
            "; reason=" & members(i).AxisReason & "; axis=" & CStr(members(i).AxisX) & "," & CStr(members(i).AxisY) & "," & CStr(members(i).AxisZ) & _
            "; sheet bounds mm=" & CStr(members(i).MinX * 1000#) & "," & CStr(members(i).MinY * 1000#) & _
            "," & CStr(members(i).MaxX * 1000#) & "," & CStr(members(i).MaxY * 1000#) & "; metadata=" & members(i).Metadata
        If members(i).Profile And members(i).AxisOK Then validProfiles = validProfiles + 1
    Next i
    WriteLog "GEOMETRY members=" & memberCount & "; usable profiles=" & validProfiles & "; straight edges=" & edgeCount
End Sub

Private Sub RequireAxes()
    Dim i As Long
    For i = 1 To memberCount
        If members(i).Profile And members(i).AxisOK = False Then _
            Fail "�� ���������� ������������� ��� �������: " & members(i).Label & ". " & members(i).AxisReason & ". �������� ������ DiagnoseFront/DiagnoseTop."
    Next i
End Sub

Private Function PropertyToken(ByVal raw As String) As String
    Dim text As String, position As Long
    text = Trim$(raw)
    If Left$(text, 1) = Chr$(34) Then text = Mid$(text, 2)
    position = InStr(text, "@@@")
    If position > 1 Then PropertyToken = UCase$(Left$(text, position - 1))
End Function

Private Function PlainNumber(ByVal text As String) As Double
    Dim value As String, i As Long, digit As String, separators As Long, digits As Long
    value = Trim$(text)
    For i = 1 To Len(value)
        digit = Mid$(value, i, 1)
        If digit >= "0" And digit <= "9" Then
            digits = digits + 1
        ElseIf digit = "." Or digit = "," Then
            separators = separators + 1
        Else
            Exit Function
        End If
    Next i
    If digits = 0 Or separators > 1 Then Exit Function
    PlainNumber = Val(Replace(value, ",", "."))
End Function

Private Function LengthFactor() As Double
    Dim units As Variant
    units = partModel.GetUnits
    If HasItems(units) = False Then Fail "�� ��������� ������� ������."
    Select Case CLng(units(LBound(units)))
        Case swMM: LengthFactor = 0.001
        Case swCM: LengthFactor = 0.01
        Case swMETER: LengthFactor = 1#
        Case swINCHES: LengthFactor = 0.0254
        Case swFEET: LengthFactor = 0.3048
        Case Else: Fail "���������������� ������� LENGTH. ����������� ���������� ������� �����."
    End Select
End Function

Private Function AxisDirection(ByVal x As Double, ByVal y As Double, ByVal z As Double) As String
    Dim norm As Double
    norm = Sqr(x * x + y * y + z * z)
    AxisDirection = "OBLIQUE"
    If norm <= 0# Then Exit Function
    If Abs(x) / norm >= AXIS_COS Then AxisDirection = "X"
    If Abs(y) / norm >= AXIS_COS Then AxisDirection = "Y"
    If Abs(z) / norm >= AXIS_COS Then AxisDirection = "Z"
End Function

Private Function Support(ByVal index As Long, ByVal coordinate As Long, ByVal sign As Double) As Double
    Dim dx As Double, dy As Double, dz As Double, norm As Double
    Dim x As Double, y As Double, z As Double, p As Variant
    dx = sign * (basisX(coordinate) - origin(coordinate))
    dy = sign * (basisY(coordinate) - origin(coordinate))
    dz = sign * (basisZ(coordinate) - origin(coordinate))
    norm = Sqr(dx * dx + dy * dy + dz * dz)
    If norm < 0.000000000001 Then Fail "������� ����������� ������ ����������. ��������� �������������� ����."
    dx = dx / norm: dy = dy / norm: dz = dz / norm
    If members(index).Body.GetExtremePoint(dx, dy, dz, x, y, z) = False Then
        WriteLog "EXTREME FAILED body=" & members(index).Label & "; coordinate=" & CStr(coordinate) & _
            "; sign=" & CStr(sign) & "; direction=" & CStr(dx) & "; " & CStr(dy) & "; " & CStr(dz)
        Fail "�� ������ ��������� " & members(index).Label
    End If
    p = Project(Array(x, y, z))
    Support = p(coordinate)
End Function

Private Function Project(ByVal source As Variant) As Variant
    ' SolidWorks requires SAFEARRAY(Double), not VBA Array() of Variants.
    Dim coordinates(0 To 2) As Double, result As Variant, i As Long
    Dim point As SldWorks.MathPoint
    If HasItems(source) = False Then Fail "��� ������� ��������� �����."
    If LBound(source) <> 0 Or UBound(source) < 2 Then Fail "�������� ���������� �����."
    For i = 0 To 2
        coordinates(i) = CDbl(source(i))
    Next i
    Set point = utility.CreatePoint(coordinates)
    If point Is Nothing Then Fail "SolidWorks �� ������ MathPoint."
    result = point.ArrayData
    If HasItems(result) = False Then Fail "MathPoint �� ������ ����������."
    If LBound(result) <> 0 Or UBound(result) < 2 Then Fail "�������� ���������� MathPoint."
    For i = 0 To 2
        If Abs(CDbl(result(i)) - coordinates(i)) > 0.000000001 Then _
            Fail "CreatePoint ������� �������� ����������: �������� ������ �������."
    Next i
    If Not componentTransform Is Nothing Then
        Set point = point.MultiplyTransform(componentTransform)
        If point Is Nothing Then Fail "�� ��������� �������������� ����������."
    End If
    Set point = point.MultiplyTransform(viewTransform)
    If point Is Nothing Then Fail "�� ��������� �������������� ����."
    result = point.ArrayData
    If HasItems(result) = False Then Fail "��� ��������� ��������������� �����."
    If LBound(result) <> 0 Or UBound(result) < 2 Then Fail "�������� ���������� ��������������� �����."
    ' Return an independent snapshot; no shared COM array references are retained.
    Project = Array(CDbl(result(0)), CDbl(result(1)), CDbl(result(2)))
End Function

Private Sub ValidateBasis()
    Dim vectors(0 To 2) As Variant, i As Long, j As Long, a As Variant, b As Variant
    Dim norm As Double, dot As Double, tolerance As Double
    vectors(0) = Array(basisX(0) - origin(0), basisX(1) - origin(1), basisX(2) - origin(2))
    vectors(1) = Array(basisY(0) - origin(0), basisY(1) - origin(1), basisY(2) - origin(2))
    vectors(2) = Array(basisZ(0) - origin(0), basisZ(1) - origin(1), basisZ(2) - origin(2))
    tolerance = viewScale * 0.000001
    For i = 0 To 2
        a = vectors(i)
        norm = Sqr(a(0) * a(0) + a(1) * a(1) + a(2) * a(2))
        WriteLog "BASIS CHECK axis=" & CStr(i) & "; length=" & CStr(norm) & "; expected=" & CStr(viewScale)
        If Abs(norm - viewScale) > tolerance Then Fail "������������ ����� ��� ��������������: " & CStr(i)
        For j = 0 To i - 1
            b = vectors(j)
            dot = a(0) * b(0) + a(1) * b(1) + a(2) * b(2)
            If Abs(dot) > viewScale * viewScale * 0.000001 Then Fail "��� �������������� �� ���������������."
        Next j
    Next i
End Sub

Private Function Straight(ByVal edge As SldWorks.Edge, ByRef a As Variant, ByRef b As Variant, ByRef length As Double) As Boolean
    Dim curve As SldWorks.Curve, va As SldWorks.Vertex, vb As SldWorks.Vertex
    Set curve = edge.GetCurve
    If curve Is Nothing Then Exit Function
    If curve.IsLine = False Then Exit Function
    Set va = edge.GetStartVertex: Set vb = edge.GetEndVertex
    If va Is Nothing Then Exit Function
    If vb Is Nothing Then Exit Function
    a = va.GetPoint: b = vb.GetPoint
    length = Sqr((a(0) - b(0)) ^ 2 + (a(1) - b(1)) ^ 2 + (a(2) - b(2)) ^ 2)
    Straight = (length > VALUE_TOL)
End Function

Private Sub AddEdge(ByVal source As SldWorks.Edge, ByVal index As Long, ByVal p As Variant, ByVal q As Variant)
    If edgeCount >= MAX_EDGES Then Fail "�������� ����� ����."
    edgeCount = edgeCount + 1
    If edgeCount = 1 Then ReDim edges(1 To 256)
    If edgeCount > UBound(edges) Then ReDim Preserve edges(1 To UBound(edges) + 256)
    Set edges(edgeCount).Source = source
    edges(edgeCount).Member = index
    edges(edgeCount).X1 = p(0): edges(edgeCount).Y1 = p(1)
    edges(edgeCount).X2 = q(0): edges(edgeCount).Y2 = q(1)
End Sub

Private Sub BuildPlan(ByVal mode As String)
    Dim i As Long, count As Long, baseBody As Long, datum As Long, target As Long
    Dim baseY As Double, tol As Double, value As Double, span As Double, bestSpan As Double, supportBottom As Double
    Dim bands As Variant, station As Long
    tol = MODEL_TOL * viewScale
    leftX = 1E+100: bottomY = 1E+100: rightX = -1E+100: topY = -1E+100
    For i = 1 To memberCount
        If members(i).Profile And members(i).AxisOK Then
            If mode <> "TOP" Or TopEligible(i) Then
            count = count + 1
            If members(i).MinX < leftX Then leftX = members(i).MinX
            If members(i).MaxX > rightX Then rightX = members(i).MaxX
            If members(i).MinY < bottomY Then bottomY = members(i).MinY
            If members(i).MaxY > topY Then topY = members(i).MaxY
            End If
        End If
    Next i
    If count = 0 Then Fail "�� ���������� ������� ����. �������� ������ Diagnose."
    If mode = "FRONT" Then
        supportBottom = 1E+100
        For i = 1 To memberCount
            If members(i).Profile And members(i).AxisOK And members(i).Direction = "X" Then
                If members(i).MinY < supportBottom Then supportBottom = members(i).MinY
            End If
        Next i
        For i = 1 To memberCount
            If members(i).Profile And members(i).AxisOK And members(i).Direction = "X" Then
                If Abs(members(i).MinY - supportBottom) <= tol Then
                    If baseBody > 0 Then
                        If Abs(members(i).MaxY - baseY) > tol Then Fail "������ ������� ������� ����� ������ ������� ������. ���� ������������."
                    End If
                    span = members(i).MaxX - members(i).MinX
                    If span > bestSpan Then
                        baseBody = i: baseY = members(i).MaxY: bestSpan = span
                    End If
                End If
            End If
        Next i
        If baseBody = 0 Then Fail "�� ������ ������ �������������� ������� �������. ����� ������ Diagnose."
        datum = Boundary(baseBody, False, baseY)
        If datum = 0 Then Fail "� �������� ������� ��� ������ ������� ������ � ��������."
        WriteLog "DATUM FRONT body=" & members(baseBody).Label & "; Y sheet mm=" & CStr(baseY * 1000#)
        For i = 1 To memberCount
            If members(i).Profile And members(i).AxisOK Then
                If members(i).Direction = "X" Or members(i).Direction = "Z" Then
                    value = members(i).MaxY - baseY
                    If value > tol Then
                        target = Boundary(i, False, members(i).MaxY)
                        If target = 0 Then Fail "��� ������� ������ �������� �������: " & members(i).Label
                        station = FindFrontStation(i, tol)
                        If station = 0 Then station = i
                        WriteLog "FRONT STATION target=" & members(i).Label & "; station=" & members(station).Label
                        AddJob datum, target, False, value / viewScale, members(i).Label, station
                    End If
                End If
            End If
        Next i
    ElseIf mode = "TOP" Then
        bands = TopBands(tol)
        MarkTopPostSupports bands, tol
        WriteLog "DATUM TOP left/bottom sheet mm=" & CStr(leftX * 1000#) & "," & CStr(bottomY * 1000#)
        WriteLog "TOP inner perimeter sheet mm=" & CStr(bands(0) * 1000#) & "; " & CStr(bands(1) * 1000#) & _
            "; " & CStr(bands(2) * 1000#) & "; " & CStr(bands(3) * 1000#)
        For i = 1 To memberCount
            If TopEligible(i) Then
                If TopNeedsX(i, bands, tol) Then
                    value = members(i).MinX - leftX
                    datum = GlobalBoundary(True, leftX, True)
                    target = Boundary(i, True, members(i).MinX)
                    If datum = 0 Or target = 0 Then Fail "��� ������ ������ ��� ������� X: " & members(i).Label
                    AddJob datum, target, True, value / viewScale, members(i).Label
                End If
                If TopNeedsY(i, bands, tol) Then
                    value = members(i).MinY - bottomY
                    datum = GlobalBoundary(False, bottomY, True)
                    target = Boundary(i, False, members(i).MinY)
                    If datum = 0 Or target = 0 Then Fail "��� ������ ������ ��� ������� Y: " & members(i).Label
                    AddJob datum, target, False, value / viewScale, members(i).Label
                End If
                If TopNeedsRearY(i, tol) Then
                    value = members(i).MaxY - bottomY
                    datum = GlobalBoundary(False, bottomY, True)
                    target = Boundary(i, False, members(i).MaxY)
                    If datum = 0 Or target = 0 Then Fail "��� ������� ������ ������� ������: " & members(i).Label
                    AddJob datum, target, False, value / viewScale, members(i).Label
                End If
            Else
                WriteLog "TOP excluded angle/other body=" & members(i).Label
            End If
        Next i
        If TOP_OVERALL_WIDTH Then
            datum = GlobalBoundary(True, leftX, True)
            target = GlobalBoundary(True, rightX, True)
            If datum = 0 Or target = 0 Then Fail "��� ������ ��� ����� ������ ���� ������."
            AddJob datum, target, True, (rightX - leftX) / viewScale, "����� ������ ����"
        End If
    End If
    SortAndPlace mode
End Sub

Private Function FindFrontStation(ByVal target As Long, ByVal tolerance As Double) As Long
    Dim i As Long, gap As Double, distance As Double, bestGap As Double, bestDistance As Double
    bestGap = 1E+100: bestDistance = 1E+100
    For i = 1 To memberCount
        If members(i).Profile And members(i).AxisOK And members(i).Direction = "Y" Then
            If members(target).MinY <= members(i).MaxY + tolerance And members(target).MaxY >= members(i).MinY - tolerance Then
                gap = 0#
                If members(target).MaxX < members(i).MinX Then gap = members(i).MinX - members(target).MaxX
                If members(target).MinX > members(i).MaxX Then gap = members(target).MinX - members(i).MaxX
                If gap <= 0.02 * viewScale + tolerance Then
                    distance = Abs((members(target).MinX + members(target).MaxX - members(i).MinX - members(i).MaxX) / 2#)
                    If gap < bestGap - tolerance Or (Abs(gap - bestGap) <= tolerance And distance < bestDistance) Then
                        FindFrontStation = i
                        bestGap = gap: bestDistance = distance
                    End If
                End If
            End If
        End If
    Next i
End Function

Private Function TopNeedsRearY(ByVal index As Long, ByVal tolerance As Double) As Boolean
    If members(index).Direction <> "X" Then Exit Function
    If members(index).MinY <= bottomY + tolerance Then Exit Function
    If IsChannelMember(index) Then TopNeedsRearY = True: Exit Function
    If members(index).CarriesTubePost Then TopNeedsRearY = True: Exit Function
    If IsTubeMember(index) Then
        If members(index).SlotChecked = False Then
            members(index).HasSlot = HasPlanarSlot(index)
            members(index).SlotChecked = True
            WriteLog "TOP SLOT body=" & members(index).Label & "; capsule=" & members(index).HasSlot
        End If
        TopNeedsRearY = members(index).HasSlot
    End If
End Function

Private Function IsTubeMember(ByVal index As Long) As Boolean
    Dim text As String, word As Variant
    text = LCase$(members(index).Metadata & " " & members(index).Label)
    For Each word In Array("����", "tube", "pipe", "rhs", "shs")
        If InStr(text, CStr(word)) > 0 Then IsTubeMember = True: Exit Function
    Next word
End Function

Private Function IsChannelMember(ByVal index As Long) As Boolean
    Dim text As String, word As Variant
    text = LCase$(members(index).Metadata & " " & members(index).Label)
    For Each word In Array("�������", "������", "channel", "upn")
        If InStr(text, CStr(word)) > 0 Then IsChannelMember = True: Exit Function
    Next word
End Function

Private Sub MarkTopPostSupports(ByVal bands As Variant, ByVal tolerance As Double)
    Dim rails As Collection, posts As Collection
    Dim rail As Variant, post As Variant, i As Long, postIndex As Long, channel As Boolean
    Set rails = New Collection: Set posts = New Collection
    For i = 1 To memberCount
        If TopEligible(i) Then
            Select Case members(i).Direction
                Case "X"
                    If (IsTubeMember(i) Or IsChannelMember(i)) And members(i).MinY > bottomY + tolerance Then rails.Add i
                Case "Y"
                    If IsChannelMember(i) And TopNeedsX(i, bands, tolerance) Then rails.Add i
                Case "Z"
                    If IsTubeMember(i) Then posts.Add i
            End Select
        End If
    Next i
    If posts.Count = 0 Or rails.Count = 0 Then Exit Sub
    For Each post In posts
        i = CLng(post)
        members(i).MinZ = Support(i, 2, -1#)
        members(i).MaxZ = Support(i, 2, 1#)
    Next post
    For Each rail In rails
        i = CLng(rail)
        members(i).MinZ = Support(i, 2, -1#)
        members(i).MaxZ = Support(i, 2, 1#)
        channel = IsChannelMember(i)
        For Each post In posts
            postIndex = CLng(post)
            If TopPostFootMeetsRail(members(postIndex), members(i), tolerance) Then
                If channel Then
                    If members(i).Direction = "Y" Then
                        members(postIndex).PostXLocatedByChannel = True
                    Else
                        members(postIndex).PostYLocatedByChannel = True
                    End If
                Else
                    members(i).CarriesTubePost = True
                End If
                WriteLog "TOP ����� ������: " & members(i).Label & " <- " & members(postIndex).Label
            End If
        Next post
    Next rail
End Sub

Private Function OverlapLength(ByVal firstMin As Double, ByVal firstMax As Double, _
                               ByVal secondMin As Double, ByVal secondMax As Double) As Double
    If secondMin > firstMin Then firstMin = secondMin
    If secondMax < firstMax Then firstMax = secondMax
    OverlapLength = firstMax - firstMin
End Function

Private Function TopPostFootMeetsRail(ByRef post As MemberInfo, ByRef rail As MemberInfo, _
                                      ByVal tolerance As Double) As Boolean
    Dim xOverlap As Double, yOverlap As Double, zOverlap As Double
    xOverlap = OverlapLength(post.MinX, post.MaxX, rail.MinX, rail.MaxX)
    yOverlap = OverlapLength(post.MinY, post.MaxY, rail.MinY, rail.MaxY)
    If xOverlap < -tolerance Or yOverlap < -tolerance Then Exit Function
    ' The foot meets the upper face of the horizontal member.
    If Abs(post.MinZ - rail.MaxZ) <= tolerance Then
        TopPostFootMeetsRail = (xOverlap > tolerance And yOverlap > tolerance)
        Exit Function
    End If
    ' An adjacent upright may attach to a side of the member at its foot.
    If post.MinZ < rail.MinZ - tolerance Or post.MinZ > rail.MaxZ + tolerance Then Exit Function
    zOverlap = OverlapLength(post.MinZ, post.MaxZ, rail.MinZ, rail.MaxZ)
    If zOverlap <= tolerance Then Exit Function
    TopPostFootMeetsRail = (Abs(xOverlap) <= tolerance And yOverlap > tolerance) Or _
                          (Abs(yOverlap) <= tolerance And xOverlap > tolerance)
End Function

Private Function HasPlanarSlot(ByVal index As Long) As Boolean
    Dim faces As Variant, loops As Variant, face As SldWorks.Face2, surface As SldWorks.Surface
    Dim contour As SldWorks.Loop2, normal As Variant, projected As Variant
    Dim i As Long, j As Long, nx As Double, ny As Double, nz As Double, norm As Double
    faces = members(index).Body.GetFaces
    If HasItems(faces) = False Then Fail "�� ��������� ����� ��� ������ ��������: " & members(index).Label
    For i = LBound(faces) To UBound(faces)
        Set face = faces(i): Set surface = face.GetSurface
        If Not surface Is Nothing Then
            If surface.IsPlane Then
                normal = face.Normal
                If HasItems(normal) Then
                    projected = Project(Array(CDbl(normal(0)), CDbl(normal(1)), CDbl(normal(2))))
                    nx = projected(0) - origin(0): ny = projected(1) - origin(1): nz = projected(2) - origin(2)
                    norm = Sqr(nx * nx + ny * ny + nz * nz)
                    If norm > 0# Then
                        If Abs(nz) / norm >= AXIS_COS Then
                            loops = face.GetLoops
                            If HasItems(loops) Then
                                For j = LBound(loops) To UBound(loops)
                                    Set contour = loops(j)
                                    If contour.IsOuter = False Then
                                        If CapsuleLoop(contour) Then HasPlanarSlot = True: Exit Function
                                    End If
                                Next j
                            End If
                        End If
                    End If
                End If
            End If
        End If
    Next i
End Function

Private Function CapsuleLoop(ByVal contour As SldWorks.Loop2) As Boolean
    Dim values As Variant, edge As SldWorks.Edge, curve As SldWorks.Curve, parameters As SldWorks.CurveParamData
    Dim circleData As Variant, a As Variant, b As Variant, segment As Variant, lines As Collection
    Dim centres(0 To 1) As Variant, angles(0 To 1) As Double, groups As Long, cap As Long
    Dim radius As Double, sweep As Double, length As Double, totalLength As Double, i As Long, k As Long
    Dim dx As Double, dy As Double, dz As Double, distance As Double, axis As Variant
    Dim dot As Double, along As Double, rx As Double, ry As Double, rz As Double
    Const PI As Double = 3.14159265358979
    Set lines = New Collection
    values = contour.GetEdges
    If HasItems(values) = False Then Exit Function
    For i = LBound(values) To UBound(values)
        Set edge = values(i): Set curve = edge.GetCurve
        If curve Is Nothing Then Exit Function
        If curve.IsLine Then
            If Straight(edge, a, b, length) = False Then Exit Function
            lines.Add Array(CDbl(a(0)), CDbl(a(1)), CDbl(a(2)), _
                (b(0) - a(0)) / length, (b(1) - a(1)) / length, (b(2) - a(2)) / length)
            totalLength = totalLength + length
        ElseIf curve.IsCircle Then
            circleData = curve.CircleParams
            Set parameters = edge.GetCurveParams3
            If parameters Is Nothing Then Exit Function
            sweep = Abs(parameters.UMaxValue - parameters.UMinValue)
            If sweep <= 0# Or sweep > PI + 0.00001 Then Exit Function
            If groups = 0 Then radius = CDbl(circleData(6))
            If radius <= VALUE_TOL Or Abs(CDbl(circleData(6)) - radius) > VALUE_TOL Then Exit Function
            cap = -1
            For k = 0 To groups - 1
                a = centres(k)
                If (circleData(0) - a(0)) ^ 2 + (circleData(1) - a(1)) ^ 2 + (circleData(2) - a(2)) ^ 2 <= MODEL_TOL ^ 2 Then cap = k
            Next k
            If cap < 0 Then
                If groups >= 2 Then Exit Function
                cap = groups: groups = groups + 1
                centres(cap) = Array(CDbl(circleData(0)), CDbl(circleData(1)), CDbl(circleData(2)))
            End If
            angles(cap) = angles(cap) + sweep
        Else
            Exit Function
        End If
    Next i
    If groups <> 2 Or lines.Count < 2 Then Exit Function
    CapsuleLoop = CapsuleGeometry(centres, angles, lines, radius, totalLength)
End Function

Private Function CapsuleGeometry(ByRef centres() As Variant, ByRef angles() As Double, _
                                 ByVal lines As Collection, ByVal radius As Double, ByVal totalLength As Double) As Boolean
    Dim a As Variant, b As Variant, axis As Variant, segment As Variant
    Dim dx As Double, dy As Double, dz As Double, distance As Double, dot As Double, along As Double
    Dim rx As Double, ry As Double, rz As Double
    Const PI As Double = 3.14159265358979
    If Abs(angles(0) - PI) > 0.00001 Or Abs(angles(1) - PI) > 0.00001 Then Exit Function
    a = centres(0): b = centres(1)
    dx = b(0) - a(0): dy = b(1) - a(1): dz = b(2) - a(2)
    distance = Sqr(dx * dx + dy * dy + dz * dz)
    If distance <= MODEL_TOL Then Exit Function
    If Abs(totalLength - 2# * distance) > MODEL_TOL Then Exit Function
    axis = Array(dx / distance, dy / distance, dz / distance)
    For Each segment In lines
        dot = segment(3) * axis(0) + segment(4) * axis(1) + segment(5) * axis(2)
        If Abs(dot) < 0.999999 Then Exit Function
        dx = segment(0) - a(0): dy = segment(1) - a(1): dz = segment(2) - a(2)
        along = dx * axis(0) + dy * axis(1) + dz * axis(2)
        If along < -MODEL_TOL Or along > distance + MODEL_TOL Then Exit Function
        rx = dx - along * axis(0): ry = dy - along * axis(1): rz = dz - along * axis(2)
        If Abs(Sqr(rx * rx + ry * ry + rz * rz) - radius) > MODEL_TOL Then Exit Function
    Next segment
    CapsuleGeometry = True
End Function

Private Function TopEligible(ByVal index As Long) As Boolean
    Dim text As String, word As Variant
    If members(index).Profile = False Or members(index).AxisOK = False Then Exit Function
    text = LCase$(members(index).Metadata & " " & members(index).Label)
    For Each word In Array("����", "�������", "������", "tube", "pipe", "channel", "rhs", "shs", "upn")
        If InStr(text, CStr(word)) > 0 Then TopEligible = True: Exit Function
    Next word
End Function

Private Function TopBands(ByVal tolerance As Double) As Variant
    Dim i As Long, leftInner As Double, rightInner As Double, bottomInner As Double, topInner As Double
    leftInner = leftX: rightInner = rightX: bottomInner = bottomY: topInner = topY
    For i = 1 To memberCount
        If TopEligible(i) Then
            If members(i).Direction = "Y" Then
                If Abs(members(i).MinX - leftX) <= tolerance Then
                    If members(i).MaxX > leftInner Then leftInner = members(i).MaxX
                End If
                If Abs(members(i).MaxX - rightX) <= tolerance Then
                    If members(i).MinX < rightInner Then rightInner = members(i).MinX
                End If
            ElseIf members(i).Direction = "X" Then
                If Abs(members(i).MinY - bottomY) <= tolerance Then
                    If members(i).MaxY > bottomInner Then bottomInner = members(i).MaxY
                End If
                If Abs(members(i).MaxY - topY) <= tolerance Then
                    If members(i).MinY < topInner Then topInner = members(i).MinY
                End If
            End If
        End If
    Next i
    If leftInner >= rightInner Or bottomInner >= topInner Then Fail "������������� �������� ������ ���� ������."
    TopBands = Array(leftInner, rightInner, bottomInner, topInner)
End Function

Private Function TopNeedsX(ByVal index As Long, ByVal bands As Variant, ByVal tolerance As Double) As Boolean
    If members(index).Direction <> "Y" And members(index).Direction <> "Z" Then Exit Function
    If members(index).PostXLocatedByChannel Then Exit Function
    TopNeedsX = (members(index).MinX > bands(0) + tolerance And members(index).MaxX < bands(1) - tolerance)
End Function

Private Function TopNeedsY(ByVal index As Long, ByVal bands As Variant, ByVal tolerance As Double) As Boolean
    If members(index).Direction <> "Z" Then Exit Function
    If members(index).PostYLocatedByChannel Then Exit Function
    TopNeedsY = (members(index).MinY > bands(2) + tolerance And members(index).MaxY < bands(3) - tolerance)
End Function

Private Function Boundary(ByVal member As Long, ByVal vertical As Boolean, ByVal coordinate As Double) As Long
    Dim i As Long, deviation As Double, offset As Double, length As Double, best As Double, tolerance As Double
    tolerance = MODEL_TOL * viewScale
    For i = 1 To edgeCount
        If edges(i).Member = member Then
            If vertical Then
                deviation = Abs(edges(i).X1 - edges(i).X2)
                offset = Abs((edges(i).X1 + edges(i).X2) / 2# - coordinate)
                length = Abs(edges(i).Y1 - edges(i).Y2)
            Else
                deviation = Abs(edges(i).Y1 - edges(i).Y2)
                offset = Abs((edges(i).Y1 + edges(i).Y2) / 2# - coordinate)
                length = Abs(edges(i).X1 - edges(i).X2)
            End If
            If deviation <= tolerance And offset <= tolerance And length > tolerance Then
                If length > best Then best = length: Boundary = i
            End If
        End If
    Next i
End Function

Private Function GlobalBoundary(ByVal vertical As Boolean, ByVal coordinate As Double, Optional ByVal onlyTop As Boolean = False) As Long
    Dim i As Long, candidate As Long, best As Double, length As Double
    For i = 1 To memberCount
        If members(i).Profile And members(i).AxisOK Then
            If onlyTop = False Or TopEligible(i) Then
            candidate = Boundary(i, vertical, coordinate)
            If candidate > 0 Then
                If vertical Then length = Abs(edges(candidate).Y2 - edges(candidate).Y1) Else length = Abs(edges(candidate).X2 - edges(candidate).X1)
                If length > best Then best = length: GlobalBoundary = candidate
            End If
            End If
        End If
    Next i
End Function

Private Sub AddJob(ByVal datum As Long, ByVal target As Long, ByVal horizontal As Boolean, ByVal value As Double, ByVal label As String, Optional ByVal station As Long = 0)
    Dim i As Long
    For i = 1 To jobCount
        If jobs(i).Horizontal = horizontal And jobs(i).Station = station Then
            If Abs(jobs(i).Expected - value) <= MODEL_TOL Then
                WriteLog "MERGED same coordinate: " & label & "; mm=" & CStr(value * 1000#)
                Exit Sub
            End If
        End If
    Next i
    jobCount = jobCount + 1
    If jobCount = 1 Then ReDim jobs(1 To 64)
    If jobCount > UBound(jobs) Then ReDim Preserve jobs(1 To UBound(jobs) + 64)
    jobs(jobCount).Datum = datum: jobs(jobCount).Target = target
    jobs(jobCount).Horizontal = horizontal: jobs(jobCount).Expected = value
    jobs(jobCount).Label = label: jobs(jobCount).Station = station
End Sub

Private Sub SortAndPlace(ByVal mode As String)
    Dim i As Long, j As Long, temp As DimensionJob, nx As Long, ny As Long, nl As Long, nt As Long
    Dim bodyIndex As Long, onLeft As Boolean, drawing As SldWorks.DrawingDoc, sheet As SldWorks.Sheet
    Dim sheetWidth As Double, sheetHeight As Double
    Dim station As Long, stationLeft() As Long, stationRight() As Long, localLeft As Double, localRight As Double
    ReDim stationLeft(1 To memberCount): ReDim stationRight(1 To memberCount)
    Set drawing = doc: Set sheet = drawing.GetCurrentSheet
    sheet.GetSize sheetWidth, sheetHeight
    WriteLog "LAYOUT sheet mm=" & CStr(sheetWidth * 1000#) & "; " & CStr(sheetHeight * 1000#)
    For i = 2 To jobCount
        j = i
        Do While j > 1
            If jobs(j).Expected >= jobs(j - 1).Expected Then Exit Do
            temp = jobs(j): jobs(j) = jobs(j - 1): jobs(j - 1) = temp
            j = j - 1
        Loop
    Next i
    For i = 1 To jobCount
        If mode = "TOP" Then
            If jobs(i).Horizontal Then
                jobs(i).AtX = leftX + jobs(i).Expected * viewScale / 2#
                jobs(i).AtY = bottomY - GAP - nx * STEP_GAP
                nx = nx + 1
            Else
                jobs(i).AtX = leftX - GAP - nl * STEP_GAP
                jobs(i).AtY = (edges(jobs(i).Datum).Y1 + edges(jobs(i).Target).Y1) / 2#
                nl = nl + 1
            End If
        ElseIf jobs(i).Horizontal Then
            jobs(i).AtX = leftX + jobs(i).Expected * viewScale / 2#
            jobs(i).AtY = bottomY - GAP - nx * STEP_GAP
            If jobs(i).AtY >= 0.005 Or packageMeasuring Then
                nx = nx + 1
            Else
                jobs(i).AtY = topY + GAP + nt * STEP_GAP
                nt = nt + 1
            End If
        Else
            bodyIndex = edges(jobs(i).Target).Member
            station = jobs(i).Station
            If mode = "FRONT" And station > 0 Then
                localLeft = members(station).MinX: localRight = members(station).MaxX
                onLeft = ((localLeft + localRight) / 2# < (leftX + rightX) / 2#)
                If onLeft Then
                    If localLeft - GAP - stationLeft(station) * STEP_GAP < 0.005 And packageMeasuring = False Then onLeft = False
                Else
                    If localRight + GAP + stationRight(station) * STEP_GAP > sheetWidth - 0.005 And packageMeasuring = False Then onLeft = True
                End If
                If onLeft Then
                    jobs(i).AtX = localLeft - GAP - stationLeft(station) * STEP_GAP
                    stationLeft(station) = stationLeft(station) + 1
                Else
                    jobs(i).AtX = localRight + GAP + stationRight(station) * STEP_GAP
                    stationRight(station) = stationRight(station) + 1
                End If
            Else
                onLeft = ((members(bodyIndex).MinX + members(bodyIndex).MaxX) / 2# < (leftX + rightX) / 2#)
                If onLeft Then
                    If leftX - GAP - nl * STEP_GAP < 0.005 And packageMeasuring = False Then onLeft = False
                Else
                    If rightX + GAP + ny * STEP_GAP > sheetWidth - 0.005 And packageMeasuring = False Then onLeft = True
                End If
                If onLeft Then
                    jobs(i).AtX = leftX - GAP - nl * STEP_GAP
                    nl = nl + 1
                Else
                    jobs(i).AtX = rightX + GAP + ny * STEP_GAP
                    ny = ny + 1
                End If
            End If
            jobs(i).AtY = (edges(jobs(i).Datum).Y1 + edges(jobs(i).Target).Y1) / 2#
        End If
        If packageMeasuring = False And (jobs(i).AtX < 0.005 Or jobs(i).AtX > sheetWidth - 0.005 Or jobs(i).AtY < 0.005 Or jobs(i).AtY > sheetHeight - 0.005) Then
            If mode = "TOP" Then Fail "��� �������� ����� � ����� ������������ �����. ���������� ����� ����� � ����� �� ����."
            Fail "��� ��������� ����� ������������ ����� �� �����. ����������� ��� ������ �� ����."
        End If
        WriteLog "PLAN " & CStr(i) & "; horizontal=" & CStr(jobs(i).Horizontal) & "; mm=" & CStr(jobs(i).Expected * 1000#) & _
            "; target=" & jobs(i).Label & "; datumEdge=" & jobs(i).Datum & "; targetEdge=" & jobs(i).Target & _
            "; station=" & CStr(jobs(i).Station) & "; anchor sheet mm=" & CStr(jobs(i).AtX * 1000#) & "; " & CStr(jobs(i).AtY * 1000#)
    Next i
End Sub

Private Function MappedEdge(ByVal index As Long) As SldWorks.Edge
    If instance Is Nothing Then
        Set MappedEdge = edges(index).Source
    Else
        Set MappedEdge = instance.GetCorrespondingEntity(edges(index).Source)
    End If
    If MappedEdge Is Nothing Then Fail "�� ������������ ����� � ����������� ����: " & index
End Function

Private Sub ProbePlan()
    Dim i As Long
    For i = 1 To jobCount
        ProbeEdge jobs(i).Datum
        ProbeEdge jobs(i).Target
    Next i
End Sub

Private Sub ProbeEdge(ByVal index As Long)
    On Error GoTo Failed
    Dim edge As SldWorks.Edge
    Set edge = MappedEdge(index)
    doc.ClearSelection2 True
    SelectMapped index, False
    WriteLog "MAP/SELECT edge=" & CStr(index) & "; OK; body=" & members(edges(index).Member).Label
    doc.ClearSelection2 True
    Exit Sub
Failed:
    WriteLog "MAP/SELECT edge=" & CStr(index) & "; FAILED " & CStr(Err.Number) & "; " & Err.Description
    On Error Resume Next
    doc.ClearSelection2 True
End Sub

Private Sub SelectMapped(ByVal index As Long, ByVal append As Boolean)
    Dim edge As SldWorks.Edge, selection As SldWorks.SelectionMgr, count As Long
    Set edge = MappedEdge(index)
    If vw.SelectEntity(edge, append) = False Then Fail "�� ������� ����� � ����: " & index
    Set selection = doc.SelectionManager
    If append Then count = 2 Else count = 1
    If selection.GetSelectedObjectCount2(-1) <> count Then Fail "�� ���������� ����� ����."
End Sub

Private Sub CreateDimensions()
    Dim i As Long, dimension As SldWorks.DisplayDimension
    oldProjected = vw.ProjectedDimensions: modeKnown = True
    vw.ProjectedDimensions = True
    If vw.ProjectedDimensions = False Then Fail "�� �������� ������������ ������� ����."
    oldPreference = sw.GetUserPreferenceToggle(swInputDimValOnCreate): preferenceKnown = True
    sw.SetUserPreferenceToggle swInputDimValOnCreate, False
    If sw.GetUserPreferenceToggle(swInputDimValOnCreate) Then Fail "�� �������� ������ ����� �������� �������."
    For i = 1 To jobCount
        phase = "dimension " & CStr(i)
        doc.ClearSelection2 True
        SelectMapped jobs(i).Datum, False
        SelectMapped jobs(i).Target, True
        If jobs(i).Horizontal Then
            Set dimension = doc.AddHorizontalDimension2(jobs(i).AtX, jobs(i).AtY, 0#)
        Else
            Set dimension = doc.AddVerticalDimension2(jobs(i).AtX, jobs(i).AtY, 0#)
        End If
        If dimension Is Nothing Then Fail "SolidWorks �� ������ ������ " & CStr(i)
        created.Add dimension
        expected.Add jobs(i).Expected
        FramePackageSupport.FormatMountingDimension dimension
        ValidateDimension dimension, jobs(i).Expected
    Next i
    doc.ClearSelection2 True
End Sub

Private Sub ValidateDimension(ByVal display As SldWorks.DisplayDimension, ByVal value As Double)
    Dim dimension As SldWorks.Dimension, annotation As SldWorks.Annotation
    Set dimension = display.GetDimension2(0)
    If dimension Is Nothing Then Fail "�� ��������� �������� �������."
    WriteLog "VALUE expected mm=" & CStr(value * 1000#) & "; actual mm=" & CStr(dimension.SystemValue * 1000#)
    If Abs(dimension.SystemValue - value) > VALUE_TOL Then Fail "������ �� ��������� � ������������ �����������."
    Set annotation = display.GetAnnotation
    If annotation Is Nothing Then Fail "��� ��������� �������."
    If annotation.IsDangling Then Fail "������ ������� ��������."
End Sub

Private Sub ValidateAll()
    Dim i As Long, display As SldWorks.DisplayDimension
    For i = 1 To created.Count
        Set display = created(i)
        ValidateDimension display, CDbl(expected(i))
    Next i
End Sub

Private Function Rollback() As Boolean
    On Error GoTo Failed
    Rollback = True
    If created Is Nothing Then Exit Function
    If doc Is Nothing Then Exit Function
    Dim i As Long, display As SldWorks.DisplayDimension
    For i = created.Count To 1 Step -1
        Set display = created(i)
        If DeleteCreated(display) = False Then Rollback = False
    Next i
    Exit Function
Failed:
    Rollback = False
End Function

Private Function DeleteCreated(ByVal display As SldWorks.DisplayDimension) As Boolean
    On Error GoTo Failed
    Dim annotation As SldWorks.Annotation, selection As SldWorks.SelectionMgr
    Set annotation = display.GetAnnotation
    If annotation Is Nothing Then Exit Function
    doc.ClearSelection2 True
    If annotation.Select3(False, Nothing) = False Then Exit Function
    Set selection = doc.SelectionManager
    If selection.GetSelectedObjectCount2(-1) <> 1 Then Exit Function
    DeleteCreated = doc.Extension.DeleteSelection2(0)
    Exit Function
Failed:
    WriteLog "DELETE FAILED " & CStr(Err.Number) & "; " & Err.Description
End Function

Private Function RestorePreference() As Boolean
    On Error GoTo Failed
    RestorePreference = True
    If preferenceKnown = False Then Exit Function
    sw.SetUserPreferenceToggle swInputDimValOnCreate, oldPreference
    If sw.GetUserPreferenceToggle(swInputDimValOnCreate) <> oldPreference Then RestorePreference = False
    Exit Function
Failed:
    RestorePreference = False
End Function

Private Function RestoreMode() As Boolean
    On Error GoTo Failed
    RestoreMode = True
    If modeKnown = False Then Exit Function
    vw.ProjectedDimensions = oldProjected
    If vw.ProjectedDimensions <> oldProjected Then RestoreMode = False
    Exit Function
Failed:
    RestoreMode = False
End Function

Private Sub WriteLog(ByVal message As String)
    On Error Resume Next
    Debug.Print message
End Sub

Private Function HasItems(ByVal values As Variant) As Boolean
    On Error GoTo EmptyArray
    If IsArray(values) Then HasItems = (UBound(values) >= LBound(values))
EmptyArray:
End Function

Private Function PointText(ByVal value As Variant) As String
    PointText = CStr(value(0)) & " | " & CStr(value(1)) & " | " & CStr(value(2))
End Function

Private Sub Fail(ByVal message As String)
    Err.Raise vbObjectError + 2401, VERSION, message
End Sub
